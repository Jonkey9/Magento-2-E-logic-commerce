<?php
namespace Elogic\Storelocator\Plugin;

use Elogic\Storelocator\Api\Data\StoreListInterface;
use Elogic\Storelocator\Model\StoreListRepository;
use Magento\UrlRewrite\Model\ResourceModel\UrlRewriteCollectionFactory;

class UrlRewriteCleaner
{
    /**
     * @var UrlRewriteCollectionFactory
     */
    protected $urlRewriteCollectionFactory;

    /**
     * UrlRewriteCleaner constructor.
     * @param UrlRewriteCollectionFactory $urlRewriteCollectionFactory
     */
    public function __construct(
        UrlRewriteCollectionFactory $urlRewriteCollectionFactory
    ) {
        $this->urlRewriteCollectionFactory = $urlRewriteCollectionFactory;
    }

    /**
     * @param StoreListRepository $subject
     * @param $result
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function afterDelete(StoreListRepository $subject, $result, StoreListInterface $storeList)
    {
        $collection = $this->urlRewriteCollectionFactory->create();
        $TargetPath = "storelist/stores/index/store_id/" . $storeList->getId() . "/";

        foreach ($collection as $item) {
            if ($TargetPath == $item->getTargetPath()) {
                $item->delete();
                break;
            }
        }
    }
}
