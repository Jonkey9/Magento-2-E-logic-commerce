<?php
namespace Elogic\Storelocator\Plugin;

use Elogic\Storelocator\Api\Data\StoreListInterface;
use Elogic\Storelocator\Model\StoreListRepository;
use Magento\UrlRewrite\Model\UrlRewriteFactory;
use Magento\UrlRewrite\Model\ResourceModel\UrlRewriteCollectionFactory;

class UrlRewriteCreator
{
    /**
     * @var UrlRewriteFactory
     */
    protected $_urlRewriteFactory;
    /**
     * @var UrlRewriteCollectionFactory
     */
    protected $urlRewriteCollectionFactory;

    /**
     * UrlRewriteCreator constructor.
     * @param UrlRewriteFactory $_urlRewriteFactory
     * @param UrlRewriteCollectionFactory $urlRewriteCollectionFactory
     */
    public function __construct(
        UrlRewriteFactory $_urlRewriteFactory,
        UrlRewriteCollectionFactory $urlRewriteCollectionFactory
    ) {
        $this->_urlRewriteFactory = $_urlRewriteFactory;
        $this->urlRewriteCollectionFactory = $urlRewriteCollectionFactory;
    }

    /**
     * @param \Elogic\Storelocator\Model\StoreListRepository $subject
     * @param $result
     * @param StoreListInterface $storeList
     */
    public function afterSave(StoreListRepository $subject, $result, StoreListInterface $storeList)
    {
        $urlRewriteModel = $this->_urlRewriteFactory->create();
        $url_key = $storeList->getUrlKey();
        $id = $storeList->getId();
        $RewriteUrl = $this->urlRewriteCollectionFactory->create()
            ->addFieldToFilter('target_path', "storelist/stores/index/store_id/" . $id . "/")
            ->getFirstItem();

        if (!$RewriteUrl->getTargetPath()) {
            $urlRewriteModel->setStoreId(1);
            $urlRewriteModel->setIsSystem(0);
            $urlRewriteModel->setIdPath(rand(1, 100000));
            $urlRewriteModel->setTargetPath("storelist/stores/index/store_id/" . $id . "/");
            $urlRewriteModel->setRequestPath("stores/" . $url_key . "/");
            $urlRewriteModel->save();
        } else {
            $RewriteUrl->setRequestPath("stores/" . $url_key . "/");
            $RewriteUrl->save();
        }
    }
}
