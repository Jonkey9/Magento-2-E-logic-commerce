<?php
namespace Elogic\Storelocator\Api;

/**
 * Interface StoreListRepositoryInterface
 * @package Elogic\Storelocator\Api
 */
interface StoreListRepositoryInterface
{

    /**
     * @param Data\StoreListInterface $storeList
     * @return mixed
     */
    public function save(
        Data\StoreListInterface $storeList
    );

    /**
     * @param $storeListId
     * @return mixed
     */
    public function get($storeListId);

    /**
     * @param $urlKey
     * @return mixed
     */
    public function getByUrlKey($urlKey);

    /**
     * @param Data\StoreListInterface $storeList
     * @return mixed
     */
    public function delete(
        Data\StoreListInterface $storeList
    );

    /**
     * @param $storeListId
     * @return mixed
     */
    public function deleteById($storeListId);
}
