<?php
namespace  Elogic\Storelocator\Api\Data;
/**
 * Interface StoreListInterface
 * @package Elogic\Storelocator\Api\Data
 */
interface StoreListInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    const ID = 'id';
    const STORE_NAME = 'store_name';
    const DESCRIPTION = 'description';
    const IMAGES = 'images';
    const ADDRESS = 'address';
    const WORK_SCHEDULE = 'work_schedule';
    const LONGITUDE = 'longitude';
    const LATITUDE = 'latitude';
    const URL_KEY = 'url_key';


    //Getters

    /**
     * @return mixed
     */
    public function getId();

    /**
     * @return mixed
     */
    public function getStoreName();

    /**
     * @return mixed
     */
    public function getDescription();

    /**
     * @return mixed
     */
    public function getImages();

    /**
     * @return mixed
     */
    public function getAddress();

    /**
     * @return mixed
     */
    public function getWorkSchedule();

    /**
     * @return mixed
     */
    public function getLongitude();

    /**
     * @return mixed
     */
    public function getLatitude();

    /**
     * @return mixed
     */
    public function getUrlKey();

    //Setters

    /**
     * @param $id
     * @return mixed
     */
    public function setID($id);

    /**
     * @param $storeName
     * @return mixed
     */
    public function setStoreName($storeName);

    /**
     * @param $description
     * @return mixed
     */
    public function setDescription($description);

    /**
     * @param $images
     * @return mixed
     */
    public function setImages($images);

    /**
     * @param $address
     * @return mixed
     */
    public function setAddress($address);

    /**
     * @param $workSchedule
     * @return mixed
     */
    public function setWorkSchedule($workSchedule);

    /**
     * @param $longitude
     * @return mixed
     */
    public function setLongitude($longitude);

    /**
     * @param $latitude
     * @return mixed
     */
    public function setLatitude($latitude);

    /**
     * @param $urlKey
     * @return mixed
     */
    public function setUrlKey($urlKey);
}
