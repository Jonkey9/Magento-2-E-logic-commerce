<?php
namespace Elogic\Storelocator\Model;

use Elogic\Storelocator\Api\Data;
use Elogic\Storelocator\Api\Data\StoreListInterfaceFactory;
use Elogic\Storelocator\Api\StoreListRepositoryInterface;
use Elogic\Storelocator\Model\ResourceModel\StoreList as ResourceStoreList;
use Elogic\Storelocator\Model\ResourceModel\StoreList\CollectionFactory as StoreListCollectionFactory;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Class StoreListRepository
 * @package Elogic\Storelocator\Model
 */
class StoreListRepository implements StoreListRepositoryInterface
{
    /**
     * @var ResourceStoreList
     */
    protected $resource;

    /**
     * @var StoreListFactory
     */
    protected $storeListFactory;

    /**
     * @var StoreListCollectionFactory
     */
    protected $storeListCollectionFactory;

    /**
     * @var StoreListInterfaceFactory
     */
    protected $dataStoreListFactory;

    /**
     * @var StoreManagerInterface
     */
    private $storeManager;




    /**
     * StoreListRepository constructor.
     * @param ResourceStoreList $resource
     * @param StoreListFactory $storeListFactory
     * @param StoreListInterfaceFactory $dataStoreListFactory
     * @param StoreListCollectionFactory $storeListCollectionFactory
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(
        ResourceStoreList $resource,
        StoreListFactory $storeListFactory,
        StoreListInterfaceFactory $dataStoreListFactory,
        StoreListCollectionFactory $storeListCollectionFactory,
        StoreManagerInterface $storeManager
    ) {
        $this->resource = $resource;
        $this->storeListFactory = $storeListFactory;
        $this->storeListCollectionFactory = $storeListCollectionFactory;
        $this->dataStoreListFactory = $dataStoreListFactory;
        $this->storeManager = $storeManager;

    }


    /**
     * @param Data\StoreListInterface $storeList
     * @return Data\StoreListInterface
     * @throws CouldNotSaveException
     */
    public function save(
        Data\StoreListInterface $storeList
    ) {
        try {
            $this->resource->save($storeList);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__($exception->getMessage()));
        }
        return $storeList;
    }

    /**
     * @param $storeListId
     * @return StoreList|mixed
     * @throws NoSuchEntityException
     */
    public function get(
        $storeListId
    ) {
        $storeList = $this->storeListFactory->create();
        $this->resource->load($storeList, $storeListId);
        if (!$storeList->getId()) {
            throw new NoSuchEntityException(__('The store with the "%1" ID doesn\'t exist.', $storeListId));
        }

        return $storeList;
    }

    /**
     * @param $urlKey
     * @return StoreList|mixed
     */
    public function getByUrlKey($urlKey)
    {
        $storelist = $this->storeListFactory->create();
        $this->resource->load($storelist, $urlKey, Data\StoreListInterface::URL_KEY);
        return $storelist;
    }


    /**
     * @param Data\StoreListInterface $storeList
     * @return bool
     * @throws CouldNotDeleteException
     */
    public function delete(
        Data\StoreListInterface $storeList
    ) {
        try {
            $this->resource->delete($storeList);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__($exception->getMessage()));
        }
        return true;
    }

    /**
     * @param $storeListId
     * @return bool|mixed
     * @throws CouldNotDeleteException
     * @throws NoSuchEntityException
     */
    public function deleteById(
        $storeListId
    ) {
        return $this->delete($this->get($storeListId));
    }
}
