<?php

namespace Elogic\Storelocator\Model;

use Elogic\Storelocator\Api\Data\StoreListInterface;
use Elogic\Storelocator\Api\Data\StoreListInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Model\Context;
use Magento\Framework\Registry;


/**
 * Class StoreList
 * @package Elogic\Storelocator\Model
 */
class StoreList extends \Magento\Framework\Model\AbstractModel implements StoreListInterface
{
    /**
     * @var StoreListInterfaceFactory
     */
    protected $store_listDataFactory;

    /**
     * @var DataObjectHelper
     */
    protected $dataObjectHelper;

    /**
     * @var string
     */
    protected $_eventPrefix = 'store_list';
    /**
     * @var string
     */
    protected $eventObject = 'store_storelocator_grid_collection';

    /**
     * StoreList constructor.
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param StoreListInterfaceFactory $store_listDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param ResourceModel\StoreList $resource
     * @param ResourceModel\StoreList\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        StoreListInterfaceFactory $store_listDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Elogic\Storelocator\Model\ResourceModel\StoreList $resource,
        \Elogic\Storelocator\Model\ResourceModel\StoreList\Collection $resourceCollection,
        array $data = []
    ) {
        $this->store_listDataFactory = $store_listDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }
    //Getters

    /**
     * @return mixed|null
     */
    public function getId()
    {
        return $this->_getData(self::ID);
    }

    /**
     * @return mixed|null
     */
    public function getStoreName()
    {
        return $this->_getData(self::STORE_NAME);
    }

    /**
     * @return mixed|null
     */
    public function getDescription()
    {
        return $this->_getData(self::DESCRIPTION);
    }

    /**
     * @return mixed|null
     */
    public function getImages()
    {
        return $this->_getData(self::IMAGES);
    }

    /**
     * @return mixed|null
     */
    public function getAddress()
    {
        return $this->_getData(self::ADDRESS);
    }

    /**
     * @return mixed|null
     */
    public function getWorkSchedule()
    {
        return $this->_getData(self::WORK_SCHEDULE);
    }

    /**
     * @return mixed|null
     */
    public function getLongitude()
    {
        return $this->_getData(self::LONGITUDE);
    }

    /**
     * @return mixed|null
     */
    public function getLatitude()
    {
        return $this->_getData(self::LATITUDE);
    }

    /**
     * @return mixed|null
     */
    public function getUrlKey()
    {
        return $this->_getData(self::URL_KEY);
    }

    //Setters

    /**
     * @param mixed $id
     * @return StoreList|mixed
     */
    public function setId($id)
    {
        return $this->setData(self::ID, $id);
    }

    /**
     * @param $storeName
     * @return StoreList|mixed
     */
    public function setStoreName($storeName)
    {
        return $this->setData(self::STORE_NAME, $storeName);
    }

    /**
     * @param $description
     * @return StoreList|mixed
     */
    public function setDescription($description)
    {
        return $this->setData(self::DESCRIPTION, $description);
    }

    /**
     * @param $images
     * @return StoreList|mixed
     */
    public function setImages($images)
    {
        return $this->setData(self::IMAGES, $images);
    }

    /**
     * @param $address
     * @return StoreList|mixed
     */
    public function setAddress($address)
    {
        return $this->setData(self::ADDRESS, $address);
    }

    /**
     * @param $workSchedule
     * @return StoreList|mixed
     */
    public function setWorkSchedule($workSchedule)
    {
        return $this->setData(self::WORK_SCHEDULE, $workSchedule);
    }

    /**
     * @param $longitude
     * @return StoreList|mixed
     */
    public function setLongitude($longitude)
    {
        return $this->setData(self::LONGITUDE, $longitude);
    }

    /**
     * @param $latitude
     * @return StoreList|mixed
     */
    public function setLatitude($latitude)
    {
        return $this->setData(self::LATITUDE, $latitude);
    }

    /**
     * @param $urlKey
     * @return StoreList|mixed
     */
    public function setUrlKey($urlKey)
    {
        return $this->setData(self::URL_KEY, $urlKey);
    }
}
